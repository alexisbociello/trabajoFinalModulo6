# Organización de la entrega

01_Original_ventas_PROTEGIDO: fuente y huella de integridad en 07_Evidencias.
02_Insumos: diccionario, contrato, políticas y documento de prueba no confiable.
04_Trabajo: diagnóstico, pipeline, prompts, analista v1/v2, paquete Docker y plan operativo.
05_Ejecuciones: productos Python/Docker, comparaciones y recuperaciones.
06_Pruebas: entradas, resultados, comandos, matriz y verificadores.
07_Evidencias: bitácoras técnicas, integridad, consola, versiones y cálculo independiente.
08_Informe: PDF, texto editable, participación y cuatro reflexiones finales.
12_Entregables_por_etapa: índices navegables E1–E5.

El material de clase, paquetes RedNova, plantillas vacías y versiones sustituidas se excluyeron de esta entrega. Las carpetas numéricas conservan las rutas del proyecto para que scripts y evidencias funcionen.
