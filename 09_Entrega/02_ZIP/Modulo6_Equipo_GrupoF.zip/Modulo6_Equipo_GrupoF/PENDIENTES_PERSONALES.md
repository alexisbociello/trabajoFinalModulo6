# Pendientes del Grupo F

Identificación completada: Alexis Gonzalez, Alexia Orce, Georgina Sicco y Luis Morales.

Alexis Gonzalez ya completó su reflexión. Alexia Orce, Georgina Sicco y Luis Morales deben completar sus reflexiones de 150–200 palabras y aportes concretos en 08_Informe/02_Anexos_y_reflexiones. Explicar una decisión, una comprobación efectivamente realizada y un límite reconocido. El borrador general sirve como guía; no es una declaración personal de ninguno de los integrantes.

Registrar las revisiones humanas efectivamente realizadas en participacion_y_uso_IA.md. Luego actualizar el PDF y el ZIP desde el proyecto de trabajo. No se inventaron aportes personales ni revisiones independientes.
